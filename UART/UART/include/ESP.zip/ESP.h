/*==================================================================================*
 * File        : ESP.h     												
 * Description : This file includes ESP Driver prototypes 				
 * Author      : 							
 * Date        : 																										*
 * version     : 1 v                                                           	    
 *==================================================================================*/

#ifndef ESP_H
#define ESP_H









void ESP_voidInit(void);
void ESP_connectWifi(void);
void ESP_connectServer(void);
u8 Esp_voidValidateCmd(void);










#endif